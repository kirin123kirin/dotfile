// PythonIndent�v���O�C�� indent.js
// @date 2014.4.12 takeharu v0.1
// @note �^�C�v�ʐݒ��[�����C���f���g]�Ƀ`�F�b�N�����ĉ�����

//�J�[�\���̂���s�ԍ�
var cPressed   = Indent.GetChar();
var nCurLine   = parseInt(Editor.ExpandParameter("$y"));
var nCurColumn = parseInt(Editor.ExpandParameter("$x"));
var sCurLine   = Editor.GetLineStr( nCurLine );
var sPreLine = ""
if(nCurLine>1){
	sPreLine = Editor.GetLineStr( nCurLine-1 );
}

//�C���f���g������̍쐬
var bTabIndent = Plugin.GetOption("Indent", "TabIndent") == 1 ? true : false;
var indentUnit = "";
if (bTabIndent) {
	indentUnit = "\t";
} else {
	var nTabSize = Editor.ChangeTabWidth( 0 );
	for (var i=0; i<nTabSize; i++) {
		indentUnit += " ";
	}
}

//���^�O�̍쐬
var bTabClose = Plugin.GetOption("Indent", "InsertClose") == 1 ? true : false;
var closingChars = {};
if (bTabClose) {
	closingChars = { '[':']' , '{':'}' , '(':')' , ':':'' };
}
//�����ʐ��`�̃I�v�V����
var bReIndentEnd = Plugin.GetOption("Indent", "AlignClose") == 1 ? true : false;
//�\�����̍쐬
var bSatateClose = Plugin.GetOption("Indent", "StatementClose") == 1 ? true : false;
var closingStatements = {};
if (bSatateClose) {
	closingStatements = { 'for':':' , 'if':':' , 'else':':' , 
	'elif':':' , 'class':':' , 'def':':' , 'with':':' , 
	'while':':' , 'try':':' , 'except':':' , 'finally':':' };
}
//�p�oRegex��PreCompile
var reSp=/^[ \t]*/

/*
TraceOut(' rw:'+nCurLine.toString()
	    +' cl:'+nCurColumn.toString()
	    +' pr:'+sPreLine
	    +' ch:'+cPressed
);
*/

if (cPressed == '\r') {	//���s�����������C���f���g
//	Editor.InsText( sPreLine.match(/^[ \t]*/) );
//	preSplit=sPreLine.split(' ');

	if(/^\s*(\w+)/.test(sPreLine)){
		var stateWord=RegExp.$1;
		if( stateWord in closingStatements){
			var stateEndChar=closingStatements[stateWord];
			if(sPreLine.indexOf(stateEndChar) == -1){
				Editor.MoveHistSet();
				Editor.Up();
				Editor.GoLineEnd();
				Editor.InsText( stateEndChar );
				Editor.MoveHistPrev();
				//Editor.Down();
				//Editor.GoLineEnd();
				sPreLine = Editor.GetLineStr( nCurLine-1 );
			}
		}
	}

	if(/([\[\({:])\s*(\#.*)?\r\n/.test(sPreLine)){
		var openChar=RegExp.$1;
		if( openChar in closingChars){
			Editor.Char(13);
			Editor.InsText( closingChars[openChar] );
			Editor.Up();
		}
		Editor.InsText( indentUnit );
	}
}
function rapen_char(bchr,echr){
	if (cPressed == echr) {
		c=0;
		for (i = nCurLine; i > 0; i--) {
			tmp=Editor.GetLineStr( i );
			nb=tmp.split(bchr).length;
			ne=tmp.split(echr).length;
			c=c+ne-nb;
			if(c<=0){
				lstr=sCurLine.slice(0,nCurColumn-1);
				sstr=tmp.match(reSp)[0];
				Editor.LineDeleteToStart ();
				Editor.InsText( lstr.replace(reSp, sstr) );
				break;
			}
		}
	}
}
if (bReIndentEnd) {
	rapen_char('\(','\)');
	rapen_char('\{','\}');
	rapen_char('\[','\]');
}

		
if (cPressed == ' ') {	//�R�[�h�X�j�y�b�g
}
