// �A�ԍ쐬
function ConvertEx_Renban()
{
	if( false == ConvertEx_Renban_() ){
		InfoMsg("�ȉ��̂悤�ȕ������I�����Ă�������\n��1:[1-9]=>123456789\n��1:[1-7,3]px =>1px 4px 7px");
	}
}

function ConvertEx_Renban_()
{
	var sel = Editor.IsTextSelected();
	if( 0 == sel || 2 == sel ){
		return false;
	}
	var str = Editor.GetSelectedString(0);
	if( str.length == 0 ){
		return false;
	}
	var ret = "";
	var reRet;
	if( (reRet = /\[([0-9]+)-([0-9]+)(,([0-9]+))?\]/.exec(str)) != null ){
		var i = parseInt(reRet[1]);
		var iEnd = parseInt(reRet[2]);
		var dx = parseInt(reRet[4]);
		if( isNaN(dx) ){
			dx = 1;
		}
		if( dx == 0 ){
			dx = 1;
		}
		var leftStr = RegExp.leftContext;
		var rightStr = RegExp.rightContext;
		if( i < iEnd ){
			while( i <= iEnd ){
				ret += leftStr + i + rightStr;
				i += dx;
			}
		}else{
			while( iEnd <= i ){
				ret += leftStr + i + rightStr;
				i -= dx;
			}
		}
	}else{
		ret = str;
	}
	Editor.InsText(ret);
	return true;
}
ConvertEx_Renban();
