// �㉺���]
function CnvertEx_Reverse()
{
	var sel = Editor.IsTextSelected();
	if( sel == 0 ){
		return;
	}
	var str = Editor.GetSelectedString(0);
	if( str.length == 0 ){
		return;
	}
	var eol;
	switch( Editor.GetLineCode() ){
		default:
		case 0: eol = "\r\n"; break;
		case 1: eol = "\r";   break;
		case 2: eol = "\n";   break;
	}
	var arr = [];
	var pos = 0;
	var start = 0;
	while( pos < str.length ){
		var code = str.charCodeAt(pos);
		if( code == 0x0a || code == 0x0d ){
			if( pos + 1 < str.length && code == 0x0d || str.charCodeAt(pos + 1) == 0x0a ){
				pos++;
			}
			arr[arr.length] = str.substring(start, pos + 1);
			start = pos + 1;
		}
		pos++;
	}
	if( start < str.length ){
		arr[arr.length] = str.substring(start) + eol;
		arr[0] = arr[0].replace(/[\r\n]+/,"");
	}
	str = arr.reverse().join("");
	if( sel == 2 ){
		Editor.InsBoxText(str);
	}else{
		Editor.InsText(str);
	}
}
CnvertEx_Reverse();
