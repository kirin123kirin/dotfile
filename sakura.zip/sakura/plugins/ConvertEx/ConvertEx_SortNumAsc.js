// ���l�\�[�g(�~��)
function CnvertEx_SortNumAsc()
{
	var sel = Editor.IsTextSelected();
	if( sel == 0 ){
		return;
	}
	if( sel == 2 ){
		return;
	}
	var str = Editor.GetSelectedString(0);
	if( str.length == 0 ){
		return;
	}
	var eol;
	switch( Editor.GetLineCode() ){
		default:
		case 0: eol = "\r\n"; break;
		case 1: eol = "\r";   break;
		case 2: eol = "\n";   break;
	}
	var arr = [];
	var pos = 0;
	var start = 0;
	var re = /-?[0-9]+/;
	while( pos < str.length ){
		var code = str.charCodeAt(pos);
		if( code == 0x0a || code == 0x0d ){
			if( pos + 1 < str.length && code == 0x0d || str.charCodeAt(pos + 1) == 0x0a ){
				pos++;
			}
			var line = str.substring(start, pos + 1);
			var ival = parseInt(re.exec(line));
			if( isNaN(ival) ){
				ival = -2147483648;
			}
			arr[arr.length] = [line,ival];
			start = pos + 1;
		}
		pos++;
	}
	if( start < str.length ){
		var line = str.substring(start) + eol;
		var ival = parseInt(re.exec(line));
		arr[arr.length] = [line,ival];
	}
	arr.sort( function (a, b){
			return a[1] - b[1];
		} );
	if( start < str.length && 0 < arr.length ){
		arr[arr.length-1][0] = arr[arr.length-1][0].replace(/[\r\n]+/,"");
	}
	for( var i = 0; i < arr.length; i++ ){
		arr[i] = arr[i][0];
	}
	str = arr.join("");
	Editor.InsText(str);
}
CnvertEx_SortNumAsc();
