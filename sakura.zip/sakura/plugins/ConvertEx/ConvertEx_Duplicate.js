// ��d��
function ConvertEx_Duplicate()
{
	if( 2 == Editor.IsTextSelected() ){
		return;
	}
	if( 0 == Editor.IsTextSelected() ){
		Editor.SelectLine(0);
	}
	var str = Editor.GetSelectedString(0);
	if( str.length == 0 ){
		return;
	}
	Editor.InsText(str + str);
}
ConvertEx_Duplicate();
