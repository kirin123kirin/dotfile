// ���s�R�[�h�폜
function ConvertEx_TrimEol(){
	var sel = Editor.IsTextSelected()
	var str = Editor.GetSelectedString(0);
	str = str.replace(/[\r\n]+/g, "");
	if( sel == 2 ){
		Editor.Delete();
	}
	Editor.InsText(str);
}
ConvertEx_TrimEol();
