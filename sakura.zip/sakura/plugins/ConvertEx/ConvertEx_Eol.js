// ���s�R�[�h����
function ConvertEx_Eol(){
	var sel = Editor.IsTextSelected();
	if( sel == 0 || sel == 2 ){
		return;
	}
	var str = Editor.GetSelectedString(0);
	if( str.length == 0 ){
		return;
	}
	var eol;
	switch( Editor.GetLineCode() ){
		default:
		case 0: eol = "\r\n"; break;
		case 1: eol = "\r";   break;
		case 2: eol = "\n";   break;
	}
	str = str.replace(/\r\n|\r|\n/g, eol);
	Editor.InsText(str);
}
ConvertEx_Eol();
