// �S�p�X�y�[�X�����p�X�y�[�X
function ConvertEx_ZenSpToHanSp(){
	var sel = Editor.IsTextSelected();
	if( sel == 0 ){
		return;
	}
	var str = Editor.GetSelectedString(0);
	str = str.replace(/�@/g, "  ");
	if( sel == 2 ){
		Editor.InsBoxText(str);
	}else{
		Editor.InsText(str);
	}
}
ConvertEx_ZenSpToHanSp();
