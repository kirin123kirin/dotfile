// �C���f���g����
function ConvertEx_IndentByFirstLine()
{
	var str = Editor.GetSelectedString(0);
	var sel = Editor.IsTextSelected();
	if( str.length == 0 || 0 == sel ){
		// ���I���Ȃ猻�ݍs���P��̍s�ɍ��킹�ăC���f���g
		Editor.GoLineTop(9);
		Editor.Down(0);
		Editor.Up_Sel(0);
		Editor.Up_Sel(0);
		str = Editor.GetSelectedString(0);
	}
	var arr = [];
	var pos = 0;
	var start = 0;
	while( pos < str.length ){
		var code = str.charCodeAt(pos);
		if( code == 0x0a || code == 0x0d ){
			if( pos + 1 < str.length && code == 0x0d || str.charCodeAt(pos + 1) == 0x0a ){
				pos++;
			}
			arr[arr.length] = str.substring(start, pos + 1);
			start = pos + 1;
		}
		pos++;
	}
	if( start < str.length ){
		arr[arr.length] = str.substring(start);
	}
	var tabsp = arr[0].match(/^[ \t�@]*/)[0];
	for( var i = 0; i < arr.length; i++ ){
		arr[i] = arr[i].replace(/^[ \t�@]*/, tabsp);
	}
	str = arr.join("");
	if( sel == 2 ){
		Editor.InsBoxText(str);
	}else{
		Editor.InsText(str);
	}
}
ConvertEx_IndentByFirstLine();
