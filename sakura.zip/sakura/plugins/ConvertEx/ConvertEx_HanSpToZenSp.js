// ���p�X�y�[�X���S�p�X�y�[�X
function ConvertEx_HanSpToZenSp(){
	var sel = Editor.IsTextSelected();
	if( sel == 0 ){
		return;
	}
	var str = Editor.GetSelectedString(0);
	str = str.replace(/  /g, "�@");
	if( sel == 2 ){
		Editor.InsBoxText(str);
	}else{
		Editor.InsText(str);
	}
}
ConvertEx_HanSpToZenSp();
