// �召��������\�[�g(����)
function CompareString(a, b)
{
	var compval = function(d){
		if( d <= 0x61 && d <= 0x7a ){
			return d - 0x20;
		}else if( d <= 0xff41 && d <= 0xff5a ){
			return d - 0x20;
		}
		return d;
	}
	var len = a.length < b.length ? a.length: b.length;
	var i = 0;
	while( i < len ){
		var ad = compval(a.charCodeAt(i));
		var bd = compval(b.charCodeAt(i));
		if( ad != bd ){
			return ad - bd;
		}
		i++;
	}
	if( a.length < b.length ){
		return -1;
	}else if( b.length < a.length ){
		return 1;
	}
	return 0;
}

function ConvertEx_SortIgnoreCaseAsc()
{
	if( 0 == Editor.IsTextSelected() ){
		return;
	}
	var str = Editor.GetSelectedString(0);
	if( str.length == 0 ){
		return;
	}
	var eol;
	switch( Editor.GetLineCode() ){
		default:
		case 0: eol = "\r\n"; break;
		case 1: eol = "\r";   break;
		case 2: eol = "\n";   break;
	}
	var arr = [];
	var pos = 0;
	var start = 0;
	while( pos < str.length ){
		var code = str.charCodeAt(pos);
		if( code == 0x0a || code == 0x0d ){
			if( pos + 1 < str.length && code == 0x0d || str.charCodeAt(pos + 1) == 0x0a ){
				pos++;
			}
			arr[arr.length] = str.substring(start, pos + 1);
			start = pos + 1;
		}
		pos++;
	}
	if( start < str.length ){
		arr[arr.length] = str.substring(start) + eol;
	}
	arr.sort( CompareString );
	if( start < str.length && 0 < arr.length ){
		arr[arr.length-1] = arr[arr.length-1].replace(/[\r\n]+/,"");
	}
	str = arr.join("");
	Editor.InsText(str);
}
ConvertEx_SortIgnoreCaseAsc();
